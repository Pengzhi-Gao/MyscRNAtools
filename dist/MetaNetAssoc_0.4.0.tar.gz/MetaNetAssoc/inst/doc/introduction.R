## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(collapse = TRUE, comment = "#>")

## -----------------------------------------------------------------------------
library(MetaNetAssoc)
example <- load_example_data()

fit <- run_metanet(
  metabolites = example$metabolites$metabolite_id,
  focus_genes = example$focus_genes,
  mpi = example$mpi,
  ppi = example$ppi,
  enrichment = example$enrichment,
  include_overlap = TRUE,
  hub_mode = "none"
)

fit
head(result_scores(fit))
result_qc(fit)

## -----------------------------------------------------------------------------
subset(
  result_edges(fit),
  metabolite_name == "Glutathione" & term_id == "GO:SIM0003"
)

## -----------------------------------------------------------------------------
fit_penalized <- run_metanet(
  example$metabolites$metabolite_id,
  mpi = example$mpi,
  ppi = example$ppi,
  enrichment = example$enrichment,
  hub_mode = "penalize"
)
head(result_scores(fit_penalized))

## -----------------------------------------------------------------------------
fit_reduced <- run_metanet(
  example$metabolites$metabolite_id,
  mpi = example$mpi,
  ppi = example$ppi,
  enrichment = example$enrichment,
  term_similarity_cutoff = 0.7
)
result_term_reduction(fit_reduced)

## ----eval=requireNamespace("ggplot2", quietly=TRUE)---------------------------
plot_term_ranking(fit, "Response to oxidative stress")
plot_score_heatmap(fit)

