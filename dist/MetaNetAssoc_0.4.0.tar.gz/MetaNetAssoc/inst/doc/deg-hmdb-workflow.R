## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(collapse = TRUE, comment = "#>")

## ----inputs, eval=FALSE-------------------------------------------------------
# # Either a vector ...
# deg <- c("CHKA", "SLC44A1", "CPT1A")
# hmdb <- c("HMDB0000122", "HMDB0000062")
# 
# # ... or tables with explicit columns.
# deg_table <- data.frame(gene = deg, log2FC = c(1.2, -0.8, 1.1), padj = c(.01, .03, .02))
# metabolite_table <- data.frame(hmdb_id = hmdb)
# 
# # Required MPI evidence-table columns (other columns are preserved as provenance).
# my_mpi_database <- data.frame(
#   hmdb_id = c("HMDB0000122", "HMDB0000062"),
#   metabolite_name = c("Choline", "L-Carnitine"),
#   relation_gene = c("CHKA", "CPT1A"),
#   mpi_source = c("curated_source", "curated_source"),
#   mpi_weight = c(.95, .90)
# )

## ----string-online, eval=FALSE------------------------------------------------
# ppi <- build_ppi_network(
#   deg_table,
#   species = "human",
#   gene_column = "gene",
#   score_threshold = 400
# )

## ----string-offline, eval=FALSE-----------------------------------------------
# ppi <- build_ppi_network(
#   deg,
#   species = "human",
#   string_data = downloaded_string_edges,
#   score_threshold = 400
# )

## ----mpi, eval=FALSE----------------------------------------------------------
# mpi <- build_mpi_network(
#   deg_table,
#   metabolite_table,
#   species = "human",
#   mpi_database = my_mpi_database,
#   gene_column = "gene",
#   hmdb_column = "hmdb_id"
# )

## ----enrichment, eval=FALSE---------------------------------------------------
# enr <- run_deg_enrichment(
#   deg_table,
#   species = "human",
#   gene_column = "gene",
#   ontology = "BP",
#   export_file = "GO_enrichment_human.csv"
# )
# 
# head(enr$raw)

## ----analysis, eval=FALSE-----------------------------------------------------
# fit <- run_metanet(
#   metabolites = hmdb,
#   mpi = mpi,
#   ppi = ppi,
#   enrichment = enr$enrichment,
#   focus_genes = deg
# )
# 
# head(result_scores(fit))
# result_qc(fit)

## ----one-call, eval=FALSE-----------------------------------------------------
# fit <- run_metanet(
#   metabolites = hmdb,
#   deg = deg,
#   species = "human",
#   mpi_database = my_mpi_database,
#   string_data = downloaded_string_edges
# )

## ----plots, eval=FALSE--------------------------------------------------------
# plot_term_ranking(fit, term_id = result_scores(fit)$term_id[1])
# plot_score_heatmap(fit)
# plot_association_network(fit)
# 
# # Every supporting metabolite--gene--gene--term path is retained.
# head(result_edges(fit))

## ----packaged-reference, eval=FALSE-------------------------------------------
# human_mpi_kegg <- load_mpi_reference("human")
# mouse_mpi_kegg <- load_mpi_reference("mouse")

